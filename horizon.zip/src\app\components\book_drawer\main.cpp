#include "drawer.h"
#include <app/pages/read/read.h>
#include <lvgl.h>
#include <app/dimensions.h>
#include <platform/common/platform_storage.h>
#include "../components.h"

lv_obj_t *drawer_obj = nullptr;

std::vector<std::string> get_booklist()
{
    std::vector<std::string> booklist;
    std::vector<uint8_t> bytes;
    if (platform::storage::get_path("booklist.txt", bytes))
    {
        std::string content(bytes.begin(), bytes.end());
        while (!content.empty())
        {
            auto newline = content.find('\n');
            std::string line = content.substr(0, newline);
            content = newline == std::string::npos ? "" : content.substr(newline + 1);
            if (!line.empty() && line.back() == '\r')
                line.pop_back();
            if (!line.empty())
                booklist.push_back(line);
        }
    }
    return booklist;
}

void toggle_drawer()
{
    if (drawer_obj == nullptr)
        return;
    if (lv_obj_has_flag(drawer_obj, LV_OBJ_FLAG_HIDDEN))
        lv_obj_clear_flag(drawer_obj, LV_OBJ_FLAG_HIDDEN);
    else
        lv_obj_add_flag(drawer_obj, LV_OBJ_FLAG_HIDDEN);
}

void init_book_drawer()
{
    lv_obj_t *scr = lv_scr_act();

    drawer_obj = lv_obj_create(scr);
    lv_obj_set_size(drawer_obj, 800, SCREEN_H);
    lv_obj_align(drawer_obj, LV_ALIGN_TOP_RIGHT, 0, 0);
    lv_obj_set_style_bg_color(drawer_obj, lv_color_hex(0xeeeeee), 0);
    lv_obj_set_style_bg_opa(drawer_obj, LV_OPA_COVER, 0);
    lv_obj_add_flag(drawer_obj, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(drawer_obj, LV_OBJ_FLAG_GESTURE_BUBBLE);

    auto booklist = get_booklist();
    for (size_t i = 0; i < booklist.size(); i++)
    {
        const std::string &bookname = booklist[i];
        lv_obj_t *btn = lv_btn_create(drawer_obj);
        lv_obj_set_width(btn, LV_PCT(100));
        lv_obj_align(btn, LV_ALIGN_TOP_LEFT, 0, i * 60);
        lv_obj_add_flag(btn, LV_OBJ_FLAG_GESTURE_BUBBLE);
        lv_obj_add_event_cb(btn, [](lv_event_t *e)
                            {
            size_t idx = (size_t)lv_event_get_user_data(e);
            auto booklist = get_booklist();
            if (idx < booklist.size())
            {
                book.currBook = booklist[idx];
                book.currBookPath = book.currBook;
                book.offset = 0;
            } }, LV_EVENT_CLICKED, (void *)i);
    }

    lv_obj_clear_flag(scr, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(scr, LV_OBJ_FLAG_GESTURE_BUBBLE);
    lv_obj_add_event_cb(scr, [](lv_event_t *e)
                        {
        lv_dir_t dir = lv_indev_get_gesture_dir(lv_indev_get_act());
        if (dir == LV_DIR_LEFT)
            toggle_drawer(); }, LV_EVENT_GESTURE, NULL);
}

void loop_book_drawer() {}