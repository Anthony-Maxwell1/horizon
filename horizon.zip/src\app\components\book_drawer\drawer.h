#include <vector>
#include <string>

std::vector<std::string> get_booklist();

std::string get_curr_book();